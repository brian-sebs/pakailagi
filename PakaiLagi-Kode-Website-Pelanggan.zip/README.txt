KODE WEBSITE PELANGGAN PAKAILAGI

File:
- public/index.html : struktur HTML halaman pelanggan
- public/styles.css : desain/tampilan website
- public/app.js     : interaksi, upload foto, seleksi, status, negosiasi, katalog

PENTING:
HTML ini menggunakan CSS dan JavaScript eksternal. Jangan pisahkan index.html dari dua file lainnya jika ingin tampilan dan interaksi lengkap.

Agar upload pengajuan benar-benar sampai ke panel admin, website harus dijalankan melalui server backend dari paket:
PakaiLagi-Web-Terhubung-Siap-Deploy.zip

Tempatkan file-file dalam folder public/ pada project server. Jalankan server sesuai panduan deployment. Membuka index.html dengan klik dua kali (file://) tidak akan menjalankan API server, sehingga pengiriman seleksi tidak berfungsi.

Website pelanggan tidak menampilkan menu panel admin. Panel admin tersedia di route /admin pada server yang sama.
